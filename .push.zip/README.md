## Webhook preprocessor theme

This theme builds a grunt file and installs the needed
Node modules to preprocess Sass, Less and Coffescript
files.

Once installed, you'll need your restart your Webhook
runserver for the watch command to properly fire.
